<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Career_Bridge</title>
</head>
<body>
    <div class="mainbox">
        <div class="header">
            <img src="Logo.png" alt="Logo" > 
            <?php
        echo"<a href='Home'>Home</a>";
        echo"<a href='Career Tips'>Career Tips</a>";
        echo"<a href='About'>About</a>";
        echo"<a href='Contact'>Contact Us</a>";    
            ?>
        </div>
    </div>
</body>
</html>